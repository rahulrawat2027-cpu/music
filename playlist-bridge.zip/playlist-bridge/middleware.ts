import { NextRequest, NextResponse } from "next/server";
import { isValidSession, currentSessionCookieName } from "./lib/auth";

// /api/sync is protected separately, by CRON_SECRET (see its route), since
// it's called by an external scheduler with no cookie jar.
const PUBLIC_PATHS = ["/login", "/api/login", "/api/sync"];

export function middleware(req: NextRequest) {
  const path = req.nextUrl.pathname;
  if (PUBLIC_PATHS.some((p) => path.startsWith(p)) || path.startsWith("/_next")) {
    return NextResponse.next();
  }
  const cookie = req.cookies.get(currentSessionCookieName())?.value;
  if (!isValidSession(cookie)) {
    if (path.startsWith("/api/")) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
    const url = req.nextUrl.clone();
    url.pathname = "/login";
    return NextResponse.redirect(url);
  }
  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
