import { NextRequest, NextResponse } from "next/server";
import { db } from "../../../../lib/db";
import { encrypt } from "../../../../lib/crypto";
import { developerToken } from "../../../../lib/services/apple";

// GET: hand the (server-signed) developer token to the client so it can
// call MusicKit.configure() and open Apple's own sign-in sheet.
export async function GET() {
  return NextResponse.json({ developerToken: await developerToken() });
}

// POST: after the client-side MusicKit.authorize() succeeds, it posts the
// resulting music-user-token here for us to store, encrypted, for the
// cron job to use later. This token never gets a client secret because
// there isn't one — it's exchanged entirely client-side by Apple's SDK.
export async function POST(req: NextRequest) {
  const { musicUserToken, storefront, displayName } = await req.json();
  if (!musicUserToken) return NextResponse.json({ error: "missing musicUserToken" }, { status: 400 });

  await db.account.upsert({
    where: { service_externalUserId: { service: "apple", externalUserId: storefront || "apple-user" } },
    create: {
      service: "apple",
      externalUserId: storefront || "apple-user",
      displayName: displayName || "Apple Music account",
      storefront: storefront || "us",
      refreshTokenEnc: await encrypt(musicUserToken),
    },
    update: { storefront: storefront || "us", refreshTokenEnc: await encrypt(musicUserToken) },
  });
  return NextResponse.json({ ok: true });
}
