import { NextRequest, NextResponse } from "next/server";
import { db } from "../../../../../lib/db";
import { encrypt } from "../../../../../lib/crypto";
import { me } from "../../../../../lib/services/spotify";

export async function GET(req: NextRequest) {
  const code = req.nextUrl.searchParams.get("code");
  const dashUrl = new URL("/dashboard", process.env.APP_URL || req.nextUrl.origin);
  if (!code) {
    dashUrl.searchParams.set("error", "Spotify sign-in was cancelled");
    return NextResponse.redirect(dashUrl);
  }

  const redirectUri = new URL("/api/auth/spotify/callback", process.env.APP_URL || req.nextUrl.origin).toString();
  const r = await fetch("https://accounts.spotify.com/api/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "authorization_code",
      code,
      redirect_uri: redirectUri,
      client_id: process.env.SPOTIFY_CLIENT_ID!,
      client_secret: process.env.SPOTIFY_CLIENT_SECRET!,
    }),
  });
  if (!r.ok) {
    dashUrl.searchParams.set("error", "Spotify token exchange failed");
    return NextResponse.redirect(dashUrl);
  }
  const j = await r.json();
  const profile = await me(j.access_token);

  await db.account.upsert({
    where: { service_externalUserId: { service: "spotify", externalUserId: profile.id } },
    create: {
      service: "spotify",
      externalUserId: profile.id,
      displayName: profile.display_name || profile.id,
      refreshTokenEnc: await encrypt(j.refresh_token),
    },
    update: { displayName: profile.display_name || profile.id, refreshTokenEnc: await encrypt(j.refresh_token) },
  });

  return NextResponse.redirect(dashUrl);
}
