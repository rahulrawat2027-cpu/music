import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
  const redirectUri = new URL("/api/auth/spotify/callback", process.env.APP_URL || req.nextUrl.origin).toString();
  const p = new URLSearchParams({
    client_id: process.env.SPOTIFY_CLIENT_ID!,
    response_type: "code",
    redirect_uri: redirectUri,
    scope: "playlist-read-private playlist-read-collaborative playlist-modify-private playlist-modify-public",
  });
  return NextResponse.redirect("https://accounts.spotify.com/authorize?" + p.toString());
}
