import { NextRequest, NextResponse } from "next/server";
import { db } from "../../../../../lib/db";
import { encrypt } from "../../../../../lib/crypto";
import { me } from "../../../../../lib/services/youtube";

export async function GET(req: NextRequest) {
  const code = req.nextUrl.searchParams.get("code");
  const dashUrl = new URL("/dashboard", process.env.APP_URL || req.nextUrl.origin);
  if (!code) {
    dashUrl.searchParams.set("error", "Google sign-in was cancelled");
    return NextResponse.redirect(dashUrl);
  }

  const redirectUri = new URL("/api/auth/google/callback", process.env.APP_URL || req.nextUrl.origin).toString();
  const r = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "authorization_code",
      code,
      redirect_uri: redirectUri,
      client_id: process.env.GOOGLE_CLIENT_ID!,
      client_secret: process.env.GOOGLE_CLIENT_SECRET!,
    }),
  });
  if (!r.ok) {
    dashUrl.searchParams.set("error", "Google token exchange failed");
    return NextResponse.redirect(dashUrl);
  }
  const j = await r.json();
  if (!j.refresh_token) {
    // Happens if you'd already granted consent before; Google only issues
    // a refresh token on first consent (or with prompt=consent, which we set).
    dashUrl.searchParams.set("error", "Google didn't return a refresh token — revoke access at myaccount.google.com/permissions and try again");
    return NextResponse.redirect(dashUrl);
  }
  const channel = await me(j.access_token);

  await db.account.upsert({
    where: { service_externalUserId: { service: "youtube", externalUserId: channel?.id || "me" } },
    create: {
      service: "youtube",
      externalUserId: channel?.id || "me",
      displayName: channel?.snippet?.title || "YouTube account",
      refreshTokenEnc: await encrypt(j.refresh_token),
    },
    update: { displayName: channel?.snippet?.title || "YouTube account", refreshTokenEnc: await encrypt(j.refresh_token) },
  });

  return NextResponse.redirect(dashUrl);
}
