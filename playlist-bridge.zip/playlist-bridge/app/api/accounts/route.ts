import { NextResponse } from "next/server";
import { db } from "../../../lib/db";
import { decrypt, encrypt } from "../../../lib/crypto";
import * as spotify from "../../../lib/services/spotify";
import * as youtube from "../../../lib/services/youtube";
import * as apple from "../../../lib/services/apple";

export async function GET() {
  const accounts = await db.account.findMany();
  const out = [];
  for (const acc of accounts) {
    let playlists: { id: string; name: string; count: number }[] = [];
    let error: string | null = null;
    try {
      const secret = acc.refreshTokenEnc ? await decrypt(acc.refreshTokenEnc) : null;
      if (acc.service === "spotify" && secret) {
        const { accessToken, refreshToken } = await spotify.refreshSpotifyToken(secret);
        if (refreshToken) await db.account.update({ where: { id: acc.id }, data: { refreshTokenEnc: await encrypt(refreshToken) } });
        playlists = await spotify.listPlaylists(accessToken);
      } else if (acc.service === "youtube" && secret) {
        const accessToken = await youtube.refreshGoogleToken(secret);
        playlists = await youtube.listPlaylists(accessToken);
      } else if (acc.service === "apple" && secret) {
        playlists = await apple.listPlaylists(secret, acc.storefront || "us");
      }
    } catch (e: any) {
      error = e.message;
    }
    out.push({ id: acc.id, service: acc.service, displayName: acc.displayName, playlists, error });
  }
  return NextResponse.json({ accounts: out });
}
