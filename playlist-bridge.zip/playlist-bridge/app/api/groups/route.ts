import { NextRequest, NextResponse } from "next/server";
import { db } from "../../../lib/db";

export async function GET() {
  const groups = await db.playlistGroup.findMany({
    include: { members: { include: { account: true } } },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json({ groups });
}

export async function POST(req: NextRequest) {
  const { name } = await req.json();
  if (!name?.trim()) return NextResponse.json({ error: "Name is required" }, { status: 400 });
  const group = await db.playlistGroup.create({ data: { name: name.trim() } });
  return NextResponse.json({ group });
}
