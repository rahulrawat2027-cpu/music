import { NextRequest, NextResponse } from "next/server";
import { db } from "../../../../../lib/db";

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const { accountId, nativePlaylistId, nativeName } = await req.json();
  const account = await db.account.findUniqueOrThrow({ where: { id: accountId } });

  const member = await db.member.upsert({
    where: { groupId_service: { groupId: params.id, service: account.service } },
    create: { groupId: params.id, accountId, service: account.service, nativePlaylistId, nativeName },
    update: { accountId, nativePlaylistId, nativeName },
  });
  // Clear any stale snapshot so the next sync treats this as a fresh link
  // (baseline capture, not a flood of "new" additions).
  await db.snapshot.deleteMany({ where: { memberId: member.id } });

  return NextResponse.json({ member });
}
