import { NextRequest, NextResponse } from "next/server";
import { makeSessionCookie, currentSessionCookieName } from "../../../lib/auth";

export async function POST(req: NextRequest) {
  const { password } = await req.json();
  if (!process.env.APP_PASSWORD) {
    return NextResponse.json({ error: "APP_PASSWORD is not configured on the server" }, { status: 500 });
  }
  if (password !== process.env.APP_PASSWORD) {
    return NextResponse.json({ error: "Wrong password" }, { status: 401 });
  }
  const res = NextResponse.json({ ok: true });
  res.cookies.set(currentSessionCookieName(), makeSessionCookie(), {
    httpOnly: true,
    secure: true,
    sameSite: "lax",
    maxAge: 60 * 60 * 24 * 30,
    path: "/",
  });
  return res;
}
