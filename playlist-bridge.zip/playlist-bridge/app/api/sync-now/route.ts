import { NextResponse } from "next/server";
import { runSync } from "../../../lib/sync";

export const maxDuration = 300;

export async function POST() {
  try {
    const summary = await runSync();
    return NextResponse.json({ ok: true, summary });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message }, { status: 500 });
  }
}
