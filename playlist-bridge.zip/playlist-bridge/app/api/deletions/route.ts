import { NextResponse } from "next/server";
import { db } from "../../../lib/db";

export async function GET() {
  const deletions = await db.pendingDeletion.findMany({
    where: { status: "pending" },
    include: { group: true },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json({ deletions });
}
