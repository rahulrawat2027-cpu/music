import { NextResponse } from "next/server";
import { rejectDeletion } from "../../../../../lib/sync";

export async function POST(_req: Request, { params }: { params: { id: string } }) {
  await rejectDeletion(params.id);
  return NextResponse.json({ ok: true });
}
