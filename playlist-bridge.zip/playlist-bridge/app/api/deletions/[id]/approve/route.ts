import { NextResponse } from "next/server";
import { applyApprovedDeletion } from "../../../../../lib/sync";

export async function POST(_req: Request, { params }: { params: { id: string } }) {
  try {
    await applyApprovedDeletion(params.id);
    return NextResponse.json({ ok: true });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
