"use client";
import { useEffect, useState } from "react";
import Link from "next/link";

type Deletion = { id: string; trackTitle: string; trackArtist: string; detectedOn: string; group: { name: string } };

export default function DeletionsPage() {
  const [items, setItems] = useState<Deletion[]>([]);
  const [busy, setBusy] = useState<string | null>(null);

  async function refresh() {
    const r = await fetch("/api/deletions");
    setItems((await r.json()).deletions);
  }
  useEffect(() => { refresh(); }, []);

  async function act(id: string, action: "approve" | "reject") {
    setBusy(id);
    await fetch(`/api/deletions/${id}/${action}`, { method: "POST" });
    await refresh();
    setBusy(null);
  }

  return (
    <div className="wrap">
      <div style={{ borderBottom: "2px solid var(--ink)", paddingBottom: 14, display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
        <h1>Pending deletions</h1>
        <Link href="/dashboard"><button className="ghost">Back to dashboard</button></Link>
      </div>
      <p style={{ color: "var(--ink-soft)" }}>A track disappeared from one service. Approve to remove it everywhere else too, or reject to keep it as-is.</p>

      {items.length === 0 ? (
        <p style={{ marginTop: 24 }}>Nothing waiting on you right now.</p>
      ) : (
        <table style={{ marginTop: 16 }}>
          <thead>
            <tr><th>Group</th><th>Track</th><th>Removed on</th><th></th></tr>
          </thead>
          <tbody>
            {items.map((d) => (
              <tr key={d.id}>
                <td>{d.group.name}</td>
                <td>{d.trackTitle}{d.trackArtist ? ` — ${d.trackArtist}` : ""}</td>
                <td className="pill">{d.detectedOn}</td>
                <td style={{ display: "flex", gap: 6 }}>
                  <button disabled={busy === d.id} onClick={() => act(d.id, "approve")}>Remove everywhere</button>
                  <button className="ghost" disabled={busy === d.id} onClick={() => act(d.id, "reject")}>Keep it</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
