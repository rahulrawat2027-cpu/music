"use client";
import { useEffect, useState } from "react";
import Link from "next/link";

type Playlist = { id: string; name: string; count: number };
type AccountRow = { id: string; service: "spotify" | "youtube" | "apple"; displayName: string; playlists: Playlist[]; error: string | null };
type Group = { id: string; name: string; members: { id: string; service: string; nativeName: string }[] };

const LABEL: Record<string, string> = { spotify: "Spotify", youtube: "YouTube", apple: "Apple Music" };

export default function Dashboard() {
  const [accounts, setAccounts] = useState<AccountRow[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [loading, setLoading] = useState(true);
  const [newGroupName, setNewGroupName] = useState("");
  const [syncing, setSyncing] = useState(false);
  const [syncMsg, setSyncMsg] = useState("");
  const [pendingCount, setPendingCount] = useState<number | null>(null);

  async function refresh() {
    setLoading(true);
    const [accRes, groupRes] = await Promise.all([fetch("/api/accounts"), fetch("/api/groups")]);
    setAccounts((await accRes.json()).accounts);
    setGroups((await groupRes.json()).groups);
    setLoading(false);
  }

  useEffect(() => {
    refresh();
    connectAppleIfReady();
  }, []);

  async function connectApple() {
    // @ts-ignore MusicKit is loaded via the script tag below
    const MusicKit = window.MusicKit;
    if (!MusicKit) { alert("Apple's MusicKit script hasn't loaded yet — try again in a second."); return; }
    const tokenRes = await fetch("/api/auth/apple");
    const { developerToken } = await tokenRes.json();
    const music = await MusicKit.configure({ developerToken, app: { name: "Playlist Bridge", build: "1.0" } });
    await music.authorize();
    let storefront = "us";
    try {
      const sf = await music.api.music("/v1/me/storefront");
      storefront = sf.data.data[0].id;
    } catch {}
    await fetch("/api/auth/apple", {
      method: "POST",
      body: JSON.stringify({ musicUserToken: music.musicUserToken, storefront, displayName: "Apple Music" }),
    });
    refresh();
  }
  function connectAppleIfReady() {} // placeholder for symmetry; connectApple runs on click

  async function createGroup(e: React.FormEvent) {
    e.preventDefault();
    if (!newGroupName.trim()) return;
    await fetch("/api/groups", { method: "POST", body: JSON.stringify({ name: newGroupName }) });
    setNewGroupName("");
    refresh();
  }

  async function linkPlaylist(groupId: string, accountId: string, playlist: Playlist) {
    await fetch(`/api/groups/${groupId}/link`, {
      method: "POST",
      body: JSON.stringify({ accountId, nativePlaylistId: playlist.id, nativeName: playlist.name }),
    });
    refresh();
  }

  async function syncNow() {
    setSyncing(true);
    setSyncMsg("");
    try {
      const r = await fetch("/api/sync-now", { method: "POST" });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || "Sync failed");
      const added = j.summary.groups.reduce((n: number, g: any) => n + Object.values(g.added || {}).reduce((a: any, b: any) => a + b, 0), 0);
      const queued = j.summary.groups.reduce((n: number, g: any) => n + (g.deletionsQueued || 0), 0);
      setSyncMsg(`Done. ${added} track additions propagated, ${queued} deletions queued for approval.`);
    } catch (e: any) {
      setSyncMsg("Error: " + e.message);
    } finally {
      setSyncing(false);
    }
  }

  return (
    <div className="wrap">
      <script src="https://js-cdn.music.apple.com/musickit/v3/musickit.js" async defer />
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", borderBottom: "2px solid var(--ink)", paddingBottom: 14 }}>
        <div>
          <h1>Playlist Bridge</h1>
          <p style={{ color: "var(--ink-soft)", margin: "6px 0 0" }}>Two-way sync across Spotify, YouTube and Apple Music. Deletions wait for your OK.</p>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <Link href="/dashboard/deletions"><button className="ghost">Pending deletions</button></Link>
          <button onClick={syncNow} disabled={syncing}>{syncing ? "Syncing…" : "Sync now"}</button>
        </div>
      </div>
      {syncMsg && <p style={{ marginTop: 12 }}>{syncMsg}</p>}

      <h2>Accounts</h2>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14 }}>
        {(["spotify", "youtube", "apple"] as const).map((service) => {
          const acc = accounts.find((a) => a.service === service);
          return (
            <div className="card" key={service}>
              <h3 style={{ margin: 0 }}>{LABEL[service]}</h3>
              <p style={{ fontSize: 12, color: "var(--ink-soft)", minHeight: 18 }}>{acc ? acc.displayName : "Not connected"}</p>
              {acc?.error && <p className="err">{acc.error}</p>}
              {service === "apple" ? (
                <button className="ghost" onClick={connectApple}>{acc ? "Reconnect" : "Connect"}</button>
              ) : (
                <a href={`/api/auth/${service === "youtube" ? "google" : service}`}>
                  <button className="ghost">{acc ? "Reconnect" : "Connect"}</button>
                </a>
              )}
            </div>
          );
        })}
      </div>

      <h2>Synced groups</h2>
      <form onSubmit={createGroup} className="card" style={{ display: "flex", gap: 8, alignItems: "flex-end" }}>
        <div style={{ flex: 1 }}>
          <label className="field" htmlFor="gn">New group name</label>
          <input id="gn" value={newGroupName} onChange={(e) => setNewGroupName(e.target.value)} placeholder="Late Night" />
        </div>
        <button type="submit">Create</button>
      </form>

      {!loading && groups.length === 0 && <p style={{ color: "var(--ink-soft)", marginTop: 12 }}>No groups yet — create one, then link a playlist from each service into it below.</p>}

      {groups.map((g) => (
        <div className="card" key={g.id} style={{ marginTop: 12 }}>
          <h3 style={{ margin: "0 0 8px" }}>{g.name}</h3>
          {(["spotify", "youtube", "apple"] as const).map((service) => {
            const member = g.members.find((m) => m.service === service);
            const acc = accounts.find((a) => a.service === service);
            return (
              <div key={service} style={{ display: "flex", gap: 8, alignItems: "center", padding: "6px 0", borderTop: "1px solid var(--rule)" }}>
                <span className="pill" style={{ width: 90 }}>{LABEL[service]}</span>
                {member ? (
                  <span>{member.nativeName}</span>
                ) : acc ? (
                  <select
                    defaultValue=""
                    onChange={(e) => {
                      const p = acc.playlists.find((pl) => pl.id === e.target.value);
                      if (p) linkPlaylist(g.id, acc.id, p);
                    }}
                  >
                    <option value="" disabled>Pick a playlist to link…</option>
                    {acc.playlists.map((p) => (
                      <option key={p.id} value={p.id}>{p.name} ({p.count})</option>
                    ))}
                  </select>
                ) : (
                  <span style={{ color: "var(--ink-soft)", fontSize: 13 }}>Connect {LABEL[service]} above first</span>
                )}
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}
