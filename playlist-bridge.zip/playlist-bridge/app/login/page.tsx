"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const router = useRouter();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    const r = await fetch("/api/login", { method: "POST", body: JSON.stringify({ password }) });
    if (r.ok) router.push("/dashboard");
    else setError((await r.json()).error || "Something went wrong");
  }

  return (
    <div className="wrap" style={{ maxWidth: 360, paddingTop: 96 }}>
      <h1>Playlist Bridge</h1>
      <form onSubmit={submit} className="card" style={{ marginTop: 24 }}>
        <label className="field" htmlFor="pw">Password</label>
        <input id="pw" type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoFocus />
        {error && <p className="err">{error}</p>}
        <button type="submit" style={{ marginTop: 12, width: "100%" }}>Enter</button>
      </form>
    </div>
  );
}
