# Playlist Bridge

Two-way playlist sync across Spotify, YouTube, and Apple Music. Additions on
any service propagate to the others automatically; deletions never do —
they queue up for your approval, on the dashboard and by email.

This is a full Next.js app (not a static page), because real two-way sync
needs somewhere to store what a playlist looked like last time, and
somewhere to keep refresh tokens server-side.

## How it works

- You link one playlist from each service into a **group** ("Late Night").
- An hourly job reads every member of every group, compares it against the
  track set stored from the last run, and:
  - **New tracks** get matched (by ISRC first, then title+artist+duration
    similarity) and added to the other members.
  - **Missing tracks** get queued as a `PendingDeletion` — nothing is
    removed until you approve it on `/dashboard/deletions`.
- Matching below a 62% confidence score is skipped rather than risking the
  wrong song.

## One-time setup

### 1. Push this repo to GitHub, import it into Vercel

Standard "New Project" → import your GitHub repo. Don't deploy yet — add
the environment variables first (Project Settings → Environment Variables),
using `.env.example` as the checklist.

### 2. Database — Neon via the Vercel Marketplace

Vercel dashboard → Storage → Marketplace Database Providers → Neon → connect
it to this project. It injects `DATABASE_URL` automatically. Then, from your
machine with that variable pulled locally (`vercel env pull`):

```bash
npm install
npm run db:push
```

This creates the tables from `prisma/schema.prisma`.

### 3. Spotify

1. [developer.spotify.com/dashboard](https://developer.spotify.com/dashboard) → Create app.
2. Redirect URI: `https://<your-domain>/api/auth/spotify/callback`
3. Copy the Client ID and Client Secret into `SPOTIFY_CLIENT_ID` / `SPOTIFY_CLIENT_SECRET`.

### 4. YouTube (Google Cloud)

1. [console.cloud.google.com](https://console.cloud.google.com) → new project → enable **YouTube Data API v3**.
2. APIs & Services → Credentials → OAuth client ID → Web application.
3. Authorized redirect URI: `https://<your-domain>/api/auth/google/callback`
4. Configure the OAuth consent screen with your account as a test user (unless you verify the app) — otherwise Google will block sign-in after a warning screen.
5. Copy the Client ID/Secret into `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET`.
6. Quota note: search costs 100 units, adding a track costs 50, against a default 10,000/day budget — roughly one 60-track playlist worth of *new* matches per day unless you request a quota increase.

### 5. Apple Music (MusicKit)

1. [developer.apple.com/account](https://developer.apple.com/account) (paid Apple Developer Program membership required).
2. Certificates, Identifiers & Profiles → Keys → create a key with **MusicKit** enabled. Download the `.p8` file — Apple only lets you download it once.
3. `APPLE_TEAM_ID` is your 10-character Team ID (top right of the developer portal). `APPLE_KEY_ID` is the key's ID. `APPLE_PRIVATE_KEY` is the full contents of the `.p8` file — paste it into Vercel's env var UI as-is (multiline values are fine there); if you're setting it via CLI, replace real newlines with `\n`.

### 6. Secrets

```bash
openssl rand -base64 32   # TOKEN_ENCRYPTION_KEY
openssl rand -hex 24      # CRON_SECRET
openssl rand -hex 24      # APP_SECRET
```

Set `APP_PASSWORD` to whatever you want to type to open the dashboard —
this is a single-user tool, not a multi-tenant one, so there's no signup.

### 7. Email digest (optional)

[resend.com](https://resend.com) → API key → `RESEND_API_KEY`. Set
`NOTIFY_EMAIL` to where you want deletion alerts sent. Skip this section
entirely and the app just relies on the in-dashboard review page.

### 8. Deploy, then wire up the hourly sync

Deploy the project. Vercel's Hobby plan only runs cron jobs once a day, so
hourly sync needs an external scheduler instead:

1. [cron-job.org](https://cron-job.org) (free) → create a job.
2. URL: `https://<your-domain>/api/sync`
3. Schedule: every hour.
4. Add a custom header: `Authorization: Bearer <your CRON_SECRET>`

The route checks that header and returns 401 without it, so nobody else can
trigger your syncs.

## Using it

1. Visit your deployed URL, enter `APP_PASSWORD`.
2. Connect each service under **Accounts**. Apple Music authorizes
   client-side through Apple's own sign-in sheet (MusicKit); Spotify and
   YouTube redirect through their OAuth pages.
3. Create a group, then pick the matching playlist from each connected
   service's dropdown to link it in.
4. Click **Sync now** to run immediately, or just wait for the hourly job.
5. Check `/dashboard/deletions` (or your email) when tracks are removed
   somewhere, and decide whether to remove them everywhere else.

## Known limitations

- **Apple Music playlists can't have individual tracks removed via the
  API.** Approving a deletion that should propagate to Apple Music will
  skip Apple silently — you'd need to remove that track by hand there.
- Matching is heuristic (title/artist/duration similarity), not perfect —
  expect the occasional wrong or missing match on remixes, live versions,
  and re-releases.
- Single-user by design: one password gates the whole dashboard, and one
  set of connected accounts per service.
