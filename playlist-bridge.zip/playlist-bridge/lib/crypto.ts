import { webcrypto } from "node:crypto";

const subtle = webcrypto.subtle;

// TOKEN_ENCRYPTION_KEY must be a 32-byte value, base64-encoded.
// Generate one with: openssl rand -base64 32
async function getKey() {
  const raw = process.env.TOKEN_ENCRYPTION_KEY;
  if (!raw) throw new Error("TOKEN_ENCRYPTION_KEY is not set");
  const bytes = Buffer.from(raw, "base64");
  return subtle.importKey("raw", bytes, "AES-GCM", false, ["encrypt", "decrypt"]);
}

export async function encrypt(plaintext: string): Promise<string> {
  const key = await getKey();
  const iv = webcrypto.getRandomValues(new Uint8Array(12));
  const ct = await subtle.encrypt({ name: "AES-GCM", iv }, key, new TextEncoder().encode(plaintext));
  const combined = Buffer.concat([Buffer.from(iv), Buffer.from(ct)]);
  return combined.toString("base64");
}

export async function decrypt(payload: string): Promise<string> {
  const key = await getKey();
  const combined = Buffer.from(payload, "base64");
  const iv = combined.subarray(0, 12);
  const ct = combined.subarray(12);
  const pt = await subtle.decrypt({ name: "AES-GCM", iv }, key, ct);
  return new TextDecoder().decode(pt);
}
