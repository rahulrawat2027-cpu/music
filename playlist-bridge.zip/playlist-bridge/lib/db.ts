import { PrismaClient } from "@prisma/client";

// Reuse the client across hot reloads in dev so we don't exhaust
// Neon's connection limit.
const g = globalThis as unknown as { prisma?: PrismaClient };

export const db = g.prisma ?? new PrismaClient();

if (process.env.NODE_ENV !== "production") g.prisma = db;
