import { SignJWT, importPKCS8 } from "jose";
import { Track, Candidate, scoreCandidate } from "../match";

// The developer token authenticates your app to Apple's catalog; it's
// signed with your MusicKit private key (.p8) and is safe to regenerate
// on every cold start — it's cheap and lasts up to 6 months if cached.
let cached: { token: string; expires: number } | null = null;

export async function developerToken(): Promise<string> {
  if (cached && Date.now() < cached.expires - 60_000) return cached.token;
  const key = await importPKCS8(process.env.APPLE_PRIVATE_KEY!.replace(/\\n/g, "\n"), "ES256");
  const expSeconds = 60 * 60 * 24 * 30; // 30 days; well under Apple's 6-month cap
  const token = await new SignJWT({})
    .setProtectedHeader({ alg: "ES256", kid: process.env.APPLE_KEY_ID! })
    .setIssuer(process.env.APPLE_TEAM_ID!)
    .setIssuedAt()
    .setExpirationTime(Math.floor(Date.now() / 1000) + expSeconds)
    .sign(key);
  cached = { token, expires: Date.now() + expSeconds * 1000 };
  return token;
}

// The music-user-token is what MusicKit hands back client-side after the
// person authorizes; store it (encrypted) and pass it alongside the
// developer token for every server-side call.
async function api(musicUserToken: string, storefront: string, path: string, opts: RequestInit = {}) {
  const dev = await developerToken();
  const r = await fetch(`https://api.music.apple.com${path}`, {
    ...opts,
    headers: {
      Authorization: "Bearer " + dev,
      "Music-User-Token": musicUserToken,
      "Content-Type": "application/json",
      ...(opts.headers || {}),
    },
  });
  if (!r.ok) throw new Error(`Apple Music ${r.status}: ${await r.text()}`);
  return r.status === 204 ? null : r.json();
}

export async function listPlaylists(musicUserToken: string, storefront: string) {
  const out: { id: string; name: string; count: number }[] = [];
  let path: string | null = "/v1/me/library/playlists?limit=100";
  while (path) {
    const j: any = await api(musicUserToken, storefront, path);
    for (const p of j.data || []) out.push({ id: p.id, name: p.attributes.name, count: p.attributes.trackCount ?? 0 });
    path = j.next ?? null;
  }
  return out;
}

export async function listTracks(musicUserToken: string, storefront: string, playlistId: string): Promise<Track[]> {
  const out: Track[] = [];
  let path: string | null = `/v1/me/library/playlists/${playlistId}/tracks?limit=100`;
  while (path) {
    let j: any;
    try {
      j = await api(musicUserToken, storefront, path);
    } catch {
      break; // empty library playlists 404 here
    }
    for (const t of j.data || []) {
      const a = t.attributes || {};
      out.push({
        title: a.name,
        artist: a.artistName,
        isrc: a.isrc ?? null,
        durationMs: a.durationInMillis ?? null,
        nativeId: a.playParams?.catalogId ?? t.id,
      });
    }
    path = j.next ?? null;
  }
  return out;
}

export async function findTrack(musicUserToken: string, storefront: string, track: Track) {
  if (track.isrc) {
    try {
      const j: any = await api(musicUserToken, storefront, `/v1/catalog/${storefront}/songs?filter[isrc]=${track.isrc}`);
      const hit = (j.data || [])[0];
      if (hit) return { id: hit.id, title: hit.attributes.name, artist: hit.attributes.artistName, confidence: 1 };
    } catch {
      /* fall through to text search */
    }
  }
  const term = encodeURIComponent(`${track.artist} ${track.title}`);
  const j: any = await api(musicUserToken, storefront, `/v1/catalog/${storefront}/search?term=${term}&types=songs&limit=5`);
  const items = j.results?.songs?.data || [];
  let best: (Candidate & { confidence: number }) | null = null;
  for (const hit of items) {
    const cand: Candidate = { id: hit.id, title: hit.attributes.name, artist: hit.attributes.artistName, durationMs: hit.attributes.durationInMillis };
    const s = scoreCandidate(track, cand);
    if (!best || s > best.confidence) best = { ...cand, confidence: s };
  }
  return best;
}

export async function createPlaylist(musicUserToken: string, storefront: string, name: string, songIds: string[]) {
  const body: any = { attributes: { name, description: "Synced with Playlist Bridge" } };
  if (songIds.length) body.relationships = { tracks: { data: songIds.map((id) => ({ id, type: "songs" })) } };
  const j: any = await api(musicUserToken, storefront, "/v1/me/library/playlists", { method: "POST", body: JSON.stringify(body) });
  return j.data[0].id as string;
}

export async function addTracks(musicUserToken: string, storefront: string, playlistId: string, songIds: string[]) {
  await api(musicUserToken, storefront, `/v1/me/library/playlists/${playlistId}/tracks`, {
    method: "POST",
    body: JSON.stringify({ data: songIds.map((id) => ({ id, type: "songs" })) }),
  });
}

// Apple's library API does not support removing individual tracks from a
// playlist. We surface this as a no-op with a warning rather than failing
// the whole sync run.
export async function removeTracks(_musicUserToken: string, _storefront: string, _playlistId: string, _songIds: string[]) {
  return { unsupported: true };
}
