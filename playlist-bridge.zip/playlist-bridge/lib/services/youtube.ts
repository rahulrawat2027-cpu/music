import { Track, Candidate, scoreCandidate } from "../match";

const BASE = "https://www.googleapis.com/youtube/v3";

export async function refreshGoogleToken(refreshToken: string): Promise<string> {
  const r = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "refresh_token",
      refresh_token: refreshToken,
      client_id: process.env.GOOGLE_CLIENT_ID!,
      client_secret: process.env.GOOGLE_CLIENT_SECRET!,
    }),
  });
  if (!r.ok) throw new Error("Google token refresh failed: " + (await r.text()));
  const j = await r.json();
  return j.access_token;
}

async function api(token: string, path: string, opts: RequestInit = {}) {
  const r = await fetch(BASE + path, {
    ...opts,
    headers: { Authorization: "Bearer " + token, "Content-Type": "application/json", ...(opts.headers || {}) },
  });
  if (!r.ok) throw new Error(`YouTube ${r.status}: ${await r.text()}`);
  return r.json();
}

export async function listPlaylists(token: string) {
  const out: { id: string; name: string; count: number }[] = [];
  let page = "";
  do {
    const j = await api(token, "/playlists?part=snippet,contentDetails&mine=true&maxResults=50" + (page ? "&pageToken=" + page : ""));
    for (const p of j.items) out.push({ id: p.id, name: p.snippet.title, count: p.contentDetails.itemCount });
    page = j.nextPageToken;
  } while (page);
  return out;
}

export async function listTracks(token: string, playlistId: string): Promise<Track[]> {
  const out: Track[] = [];
  let page = "";
  do {
    const j = await api(token, `/playlistItems?part=snippet&playlistId=${playlistId}&maxResults=50` + (page ? "&pageToken=" + page : ""));
    for (const it of j.items) {
      const s = it.snippet;
      if (!s || s.title === "Deleted video" || s.title === "Private video") continue;
      const parts: string[] = s.title.split(" - ");
      const hasDash = parts.length > 1;
      out.push({
        title: hasDash ? parts.slice(1).join(" - ") : s.title,
        artist: hasDash ? parts[0] : (s.videoOwnerChannelTitle || "").replace(/ - Topic$/, ""),
        isrc: null,
        durationMs: null,
        nativeId: s.resourceId.videoId,
      });
    }
    page = j.nextPageToken;
  } while (page);
  return out;
}

export async function findTrack(token: string, track: Track) {
  const q = `${track.artist} ${track.title}`;
  const j = await api(token, "/search?part=snippet&type=video&videoCategoryId=10&maxResults=5&q=" + encodeURIComponent(q));
  let best: (Candidate & { confidence: number }) | null = null;
  for (const it of j.items || []) {
    const title: string = it.snippet.title;
    const parts = title.split(" - ");
    const cand: Candidate = {
      id: it.id.videoId,
      title: parts.length > 1 ? parts.slice(1).join(" - ") : title,
      artist: parts.length > 1 ? parts[0] : it.snippet.channelTitle.replace(/ - Topic$/, ""),
    };
    const s = scoreCandidate(track, cand);
    if (!best || s > best.confidence) best = { ...cand, confidence: s };
  }
  return best;
}

export async function createPlaylist(token: string, name: string) {
  const j = await api(token, "/playlists?part=snippet,status", {
    method: "POST",
    body: JSON.stringify({ snippet: { title: name, description: "Synced with Playlist Bridge" }, status: { privacyStatus: "private" } }),
  });
  return j.id as string;
}

export async function addTracks(token: string, playlistId: string, videoIds: string[]) {
  for (const videoId of videoIds) {
    await api(token, "/playlistItems?part=snippet", {
      method: "POST",
      body: JSON.stringify({ snippet: { playlistId, resourceId: { kind: "youtube#video", videoId } } }),
    });
  }
}

// Removing from YouTube needs each item's playlistItem id (not the video
// id), so we look it up first.
export async function removeTracks(token: string, playlistId: string, videoIds: string[]) {
  const j = await api(token, `/playlistItems?part=snippet&playlistId=${playlistId}&maxResults=50`);
  const byVideo = new Map<string, string>();
  for (const it of j.items || []) byVideo.set(it.snippet.resourceId.videoId, it.id);
  for (const videoId of videoIds) {
    const itemId = byVideo.get(videoId);
    if (itemId) await api(token, `/playlistItems?id=${itemId}`, { method: "DELETE" });
  }
}

export async function me(token: string) {
  const j = await api(token, "/channels?part=snippet&mine=true");
  return j.items?.[0];
}
