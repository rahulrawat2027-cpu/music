import { Track, Candidate, scoreCandidate } from "../match";

const BASE = "https://api.spotify.com/v1";

export async function refreshSpotifyToken(refreshToken: string): Promise<{ accessToken: string; refreshToken?: string }> {
  const r = await fetch("https://accounts.spotify.com/api/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "refresh_token",
      refresh_token: refreshToken,
      client_id: process.env.SPOTIFY_CLIENT_ID!,
      client_secret: process.env.SPOTIFY_CLIENT_SECRET!,
    }),
  });
  if (!r.ok) throw new Error("Spotify token refresh failed: " + (await r.text()));
  const j = await r.json();
  return { accessToken: j.access_token, refreshToken: j.refresh_token };
}

async function api(token: string, path: string, opts: RequestInit = {}) {
  const r = await fetch(BASE + path, {
    ...opts,
    headers: { Authorization: "Bearer " + token, "Content-Type": "application/json", ...(opts.headers || {}) },
  });
  if (!r.ok) throw new Error(`Spotify ${r.status}: ${await r.text()}`);
  return r.status === 204 ? null : r.json();
}

export async function listPlaylists(token: string) {
  const out: { id: string; name: string; count: number }[] = [];
  let url: string | null = "/me/playlists?limit=50";
  while (url) {
    const j = await api(token, url);
    for (const p of j.items) out.push({ id: p.id, name: p.name, count: p.tracks.total });
    url = j.next ? j.next.replace(BASE, "") : null;
  }
  return out;
}

export async function listTracks(token: string, playlistId: string): Promise<Track[]> {
  const out: Track[] = [];
  let url: string | null = `/playlists/${playlistId}/tracks?limit=100`;
  while (url) {
    const j = await api(token, url);
    for (const it of j.items) {
      const t = it.track;
      if (!t || t.is_local || t.type !== "track") continue;
      out.push({
        title: t.name,
        artist: (t.artists || []).map((a: any) => a.name).join(", "),
        isrc: t.external_ids?.isrc ?? null,
        durationMs: t.duration_ms,
        nativeId: t.uri,
      });
    }
    url = j.next ? j.next.replace(BASE, "") : null;
  }
  return out;
}

export async function findTrack(token: string, track: Track) {
  if (track.isrc) {
    const j = await api(token, "/search?type=track&limit=1&q=" + encodeURIComponent("isrc:" + track.isrc));
    const hit = j.tracks.items[0];
    if (hit) return { id: hit.uri, title: hit.name, artist: hit.artists.map((a: any) => a.name).join(", "), confidence: 1 };
  }
  const q = `track:${track.title} artist:${track.artist}`;
  const j = await api(token, "/search?type=track&limit=5&q=" + encodeURIComponent(q));
  let best: (Candidate & { confidence: number }) | null = null;
  for (const hit of j.tracks.items) {
    const cand: Candidate = { id: hit.uri, title: hit.name, artist: hit.artists.map((a: any) => a.name).join(", "), durationMs: hit.duration_ms };
    const s = scoreCandidate(track, cand);
    if (!best || s > best.confidence) best = { ...cand, confidence: s };
  }
  return best;
}

export async function createPlaylist(token: string, userId: string, name: string) {
  const p = await api(token, `/users/${userId}/playlists`, {
    method: "POST",
    body: JSON.stringify({ name, public: false, description: "Synced with Playlist Bridge" }),
  });
  return p.id as string;
}

export async function addTracks(token: string, playlistId: string, uris: string[]) {
  for (let i = 0; i < uris.length; i += 100) {
    await api(token, `/playlists/${playlistId}/tracks`, { method: "POST", body: JSON.stringify({ uris: uris.slice(i, i + 100) }) });
  }
}

export async function removeTracks(token: string, playlistId: string, uris: string[]) {
  for (let i = 0; i < uris.length; i += 100) {
    await api(token, `/playlists/${playlistId}/tracks`, {
      method: "DELETE",
      body: JSON.stringify({ tracks: uris.slice(i, i + 100).map((uri) => ({ uri })) }),
    });
  }
}

export async function me(token: string) {
  return api(token, "/me");
}
