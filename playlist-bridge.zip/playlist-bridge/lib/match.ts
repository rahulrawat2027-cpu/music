// Canonical track representation used across all three services.
export type Track = {
  title: string;
  artist: string;
  isrc?: string | null;
  durationMs?: number | null;
  nativeId: string; // the service's own id for this track (uri / videoId / catalog id)
};

export type Candidate = {
  id: string;
  title: string;
  artist: string;
  durationMs?: number | null;
};

const NOISE =
  /\s*[([][^)\]]*(remaster|remastered|live|version|edit|mix|mono|stereo|deluxe|bonus|explicit|feat\.?|ft\.?|with )[^)\]]*[)\]]/gi;

export function normTitle(t: string | null | undefined): string {
  return (t ?? "")
    .replace(NOISE, "")
    .replace(/\s+-\s+(remaster|remastered|live|radio edit|single version).*$/i, "")
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

export function normArtist(a: string | null | undefined): string {
  return (a ?? "")
    .split(/,|&|feat\.?|ft\.?|\sand\s/i)[0]
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

// Token-overlap similarity. Crude, but robust to word order and cheap to run
// at playlist scale without pulling in a real NLP dependency.
function similar(a: string, b: string): number {
  if (!a || !b) return 0;
  if (a === b) return 1;
  const A = new Set(a.split(" "));
  const B = new Set(b.split(" "));
  let hit = 0;
  A.forEach((t) => {
    if (B.has(t)) hit++;
  });
  return (2 * hit) / (A.size + B.size);
}

export function scoreCandidate(src: Track, cand: Candidate): number {
  const t = similar(normTitle(src.title), normTitle(cand.title));
  const a = similar(normArtist(src.artist), normArtist(cand.artist));
  let s = t * 0.65 + a * 0.35;
  if (src.durationMs && cand.durationMs) {
    const d = Math.abs(src.durationMs - cand.durationMs);
    if (d < 4000) s += 0.08;
    else if (d > 20000) s -= 0.25;
  }
  return Math.max(0, Math.min(1, s));
}

// The confidence floor a match needs to be written to a destination
// playlist. Below this, we'd rather skip the track than add the wrong song.
export const MATCH_THRESHOLD = 0.62;

// Canonical key for a track, used to diff snapshots across services.
// Prefer ISRC (a real cross-service identifier); fall back to a
// normalized title+artist pair when a service doesn't expose one
// (YouTube never does).
export function trackKey(t: Track): string {
  if (t.isrc) return "isrc:" + t.isrc.toUpperCase();
  return "ta:" + normTitle(t.title) + "::" + normArtist(t.artist);
}
