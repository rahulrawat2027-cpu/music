import { Resend } from "resend";
import { db } from "./db";

export async function sendDeletionDigest(newCount: number) {
  if (!process.env.RESEND_API_KEY || !process.env.NOTIFY_EMAIL) return; // email is optional

  const resend = new Resend(process.env.RESEND_API_KEY);
  const pending = await db.pendingDeletion.findMany({
    where: { status: "pending" },
    include: { group: true },
    orderBy: { createdAt: "desc" },
    take: 25,
  });

  const rows = pending
    .map((d) => `<li><strong>${escapeHtml(d.group.name)}</strong> — ${escapeHtml(d.trackTitle)} by ${escapeHtml(d.trackArtist)} (removed on ${d.detectedOn})</li>`)
    .join("");

  await resend.emails.send({
    from: process.env.NOTIFY_FROM_EMAIL || "Playlist Bridge <onboarding@resend.dev>",
    to: process.env.NOTIFY_EMAIL,
    subject: `${newCount} new deletion${newCount === 1 ? "" : "s"} awaiting approval`,
    html: `<p>${newCount} track${newCount === 1 ? " was" : "s were"} removed on one service and ${newCount === 1 ? "is" : "are"} waiting for your OK before disappearing everywhere else.</p>
      <ul>${rows}</ul>
      <p><a href="${process.env.APP_URL || ""}/dashboard/deletions">Review in the dashboard</a></p>`,
  });
}

function escapeHtml(s: string) {
  return s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" } as any)[c]);
}
