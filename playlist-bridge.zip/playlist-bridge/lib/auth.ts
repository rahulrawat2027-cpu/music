import { cookies } from "next/headers";
import { createHmac, timingSafeEqual } from "node:crypto";

const COOKIE = "pb_session";

function sign(value: string) {
  return createHmac("sha256", process.env.APP_SECRET || "dev-secret").update(value).digest("hex");
}

export function makeSessionCookie(): string {
  const value = "ok";
  return `${value}.${sign(value)}`;
}

export function isValidSession(cookieValue: string | undefined): boolean {
  if (!cookieValue) return false;
  const [value, sig] = cookieValue.split(".");
  if (!value || !sig) return false;
  const expected = sign(value);
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}

export function currentSessionCookieName() {
  return COOKIE;
}

export async function isAuthed(): Promise<boolean> {
  const jar = await cookies();
  return isValidSession(jar.get(COOKIE)?.value);
}
