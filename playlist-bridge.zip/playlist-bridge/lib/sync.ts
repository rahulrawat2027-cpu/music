import { db } from "./db";
import { decrypt, encrypt } from "./crypto";
import { Track, trackKey, MATCH_THRESHOLD } from "./match";
import * as spotify from "./services/spotify";
import * as youtube from "./services/youtube";
import * as apple from "./services/apple";
import { sendDeletionDigest } from "./email";

type MemberWithAccount = Awaited<ReturnType<typeof loadMember>>;

async function loadMember(memberId: string) {
  return db.member.findUniqueOrThrow({ where: { id: memberId }, include: { account: true, snapshot: true } });
}

// Returns a fresh access credential for a member's service, refreshing
// where the service requires it. Spotify/YouTube refresh tokens rotate
// via OAuth; Apple's music-user-token is long-lived and just decrypted.
async function credential(account: { service: string; refreshTokenEnc: string | null; storefront: string | null; id: string }) {
  if (!account.refreshTokenEnc) throw new Error(`${account.service} account ${account.id} has no stored token`);
  const secret = await decrypt(account.refreshTokenEnc);
  if (account.service === "spotify") {
    const { accessToken, refreshToken } = await spotify.refreshSpotifyToken(secret);
    if (refreshToken) {
      await db.account.update({ where: { id: account.id }, data: { refreshTokenEnc: await encrypt(refreshToken) } });
    }
    return { accessToken };
  }
  if (account.service === "youtube") {
    const accessToken = await youtube.refreshGoogleToken(secret);
    return { accessToken };
  }
  // apple: the stored secret IS the music-user-token, used directly.
  return { musicUserToken: secret, storefront: account.storefront ?? "us" };
}

async function fetchTracks(member: NonNullable<MemberWithAccount>): Promise<Track[]> {
  const cred = await credential(member.account);
  if (member.service === "spotify") return spotify.listTracks(cred.accessToken!, member.nativePlaylistId);
  if (member.service === "youtube") return youtube.listTracks(cred.accessToken!, member.nativePlaylistId);
  return apple.listTracks(cred.musicUserToken!, cred.storefront!, member.nativePlaylistId);
}

async function findOnService(member: NonNullable<MemberWithAccount>, track: Track) {
  const cred = await credential(member.account);
  if (member.service === "spotify") return spotify.findTrack(cred.accessToken!, track);
  if (member.service === "youtube") return youtube.findTrack(cred.accessToken!, track);
  return apple.findTrack(cred.musicUserToken!, cred.storefront!, track);
}

async function addToService(member: NonNullable<MemberWithAccount>, ids: string[]) {
  const cred = await credential(member.account);
  if (!ids.length) return;
  if (member.service === "spotify") return spotify.addTracks(cred.accessToken!, member.nativePlaylistId, ids);
  if (member.service === "youtube") return youtube.addTracks(cred.accessToken!, member.nativePlaylistId, ids);
  return apple.addTracks(cred.musicUserToken!, cred.storefront!, member.nativePlaylistId, ids);
}

async function removeFromService(member: NonNullable<MemberWithAccount>, ids: string[]) {
  const cred = await credential(member.account);
  if (!ids.length) return;
  if (member.service === "spotify") return spotify.removeTracks(cred.accessToken!, member.nativePlaylistId, ids);
  if (member.service === "youtube") return youtube.removeTracks(cred.accessToken!, member.nativePlaylistId, ids);
  return apple.removeTracks(cred.musicUserToken!, cred.storefront!, member.nativePlaylistId, ids);
}

/**
 * Syncs every linked playlist group. Additions detected on any member are
 * matched and written to every other member automatically. Deletions are
 * never written automatically — they're recorded as PendingDeletion rows
 * and reported by email, per your approval-required policy. Call
 * applyApprovedDeletions() separately once you've reviewed them.
 */
export async function runSync() {
  const run = await db.syncRun.create({ data: {} });
  const summary: Record<string, any> = { groups: [] };
  let newDeletions = 0;

  try {
    const groups = await db.playlistGroup.findMany({ include: { members: { include: { account: true, snapshot: true } } } });

    for (const group of groups) {
      const groupSummary: any = { group: group.name, added: {}, deletionsQueued: 0 };
      if (group.members.length < 2) continue;

      // 1. Read current state of every member.
      const current: Record<string, { member: (typeof group.members)[number]; tracks: Track[] }> = {};
      for (const member of group.members) {
        try {
          current[member.id] = { member, tracks: await fetchTracks(member as any) };
        } catch (e: any) {
          groupSummary[`error_${member.service}`] = e.message;
        }
      }

      // 2. Diff each member against its snapshot to find additions/removals.
      //    A member with no snapshot yet is a first run: capture the
      //    baseline without treating existing tracks as new.
      //    Snapshots store {k, title, artist} triples (not bare keys) so
      //    that a later deletion can be displayed by name even when its
      //    key is an ISRC rather than a title.
      type SnapEntry = { k: string; title: string; artist: string };
      const diffs: Record<string, { added: Track[]; removed: SnapEntry[] }> = {};
      for (const [memberId, { member, tracks }] of Object.entries(current)) {
        const currEntries: SnapEntry[] = tracks.map((t) => ({ k: trackKey(t), title: t.title, artist: t.artist }));
        if (!member.snapshot) {
          diffs[memberId] = { added: [], removed: [] };
          continue;
        }
        const prevEntries: SnapEntry[] = Array.isArray(member.snapshot.trackKeys) ? (member.snapshot.trackKeys as unknown as SnapEntry[]) : [];
        const prevSet = new Set(prevEntries.map((e) => e.k));
        const currSet = new Set(currEntries.map((e) => e.k));
        diffs[memberId] = {
          added: tracks.filter((t) => !prevSet.has(trackKey(t))),
          removed: prevEntries.filter((e) => !currSet.has(e.k)),
        };
      }

      // 3. Propagate additions from every member to every other member.
      for (const [memberId, diff] of Object.entries(diffs)) {
        if (!diff.added.length) continue;
        const source = current[memberId].member;
        for (const [otherId, { member: dest }] of Object.entries(current)) {
          if (otherId === memberId) continue;
          const matchedIds: string[] = [];
          for (const track of diff.added) {
            try {
              const hit = await findOnService(dest as any, track);
              if (hit && hit.confidence >= MATCH_THRESHOLD) matchedIds.push(hit.id);
            } catch (e: any) {
              groupSummary[`search_error_${dest.service}`] = e.message;
            }
          }
          if (matchedIds.length) {
            await addToService(dest as any, matchedIds);
            groupSummary.added[dest.service] = (groupSummary.added[dest.service] || 0) + matchedIds.length;
          }
        }
      }

      // 4. Queue removals for approval instead of propagating them.
      for (const [memberId, diff] of Object.entries(diffs)) {
        if (!diff.removed.length) continue;
        const source = current[memberId].member;
        for (const entry of diff.removed) {
          const existing = await db.pendingDeletion.findFirst({ where: { groupId: group.id, trackKey: entry.k, status: "pending" } });
          if (existing) continue;
          await db.pendingDeletion.create({
            data: { groupId: group.id, detectedOn: source.service, trackKey: entry.k, trackTitle: entry.title || "(unknown)", trackArtist: entry.artist || "" },
          });
          newDeletions++;
          groupSummary.deletionsQueued++;
        }
      }

      // 5. Snapshot current state (post-addition) for next run's diff.
      for (const [memberId, { member, tracks }] of Object.entries(current)) {
        // Union in tracks added elsewhere this run, so the new baseline
        // reflects step 3's writes and isn't re-detected as "missing" here
        // next time (this member won't actually have them until its own
        // next read, but recording them now avoids a false deletion).
        const addedHere = Object.values(diffs).flatMap((d) => d.added);
        const byKey = new Map<string, SnapEntry>();
        tracks.forEach((t) => byKey.set(trackKey(t), { k: trackKey(t), title: t.title, artist: t.artist }));
        addedHere.forEach((t) => {
          const k = trackKey(t);
          if (!byKey.has(k)) byKey.set(k, { k, title: t.title, artist: t.artist });
        });
        const entries = Array.from(byKey.values());
        await db.snapshot.upsert({
          where: { memberId: member.id },
          create: { memberId: member.id, trackKeys: entries as any },
          update: { trackKeys: entries as any },
        });
      }

      summary.groups.push(groupSummary);
    }

    await db.syncRun.update({ where: { id: run.id }, data: { finishedAt: new Date(), summary } });

    if (newDeletions > 0) {
      await sendDeletionDigest(newDeletions).catch(() => {});
    }

    return summary;
  } catch (e: any) {
    await db.syncRun.update({ where: { id: run.id }, data: { finishedAt: new Date(), error: e.message } });
    throw e;
  }
}

/** Applies a single approved deletion to every OTHER member in its group. */
export async function applyApprovedDeletion(deletionId: string) {
  const del = await db.pendingDeletion.findUniqueOrThrow({ where: { id: deletionId }, include: { group: { include: { members: { include: { account: true, snapshot: true } } } } } });
  for (const member of del.group.members) {
    if (member.service === del.detectedOn) continue;
    const tracks = await fetchTracks(member as any);
    const match = tracks.find((t) => trackKey(t) === del.trackKey);
    if (!match) continue;
    await removeFromService(member as any, [match.nativeId]);
    const prevEntries: { k: string; title: string; artist: string }[] = Array.isArray(member.snapshot?.trackKeys)
      ? (member.snapshot!.trackKeys as any)
      : [];
    await db.snapshot.update({ where: { memberId: member.id }, data: { trackKeys: prevEntries.filter((e) => e.k !== del.trackKey) as any } });
  }
  await db.pendingDeletion.update({ where: { id: deletionId }, data: { status: "approved", resolvedAt: new Date() } });
}

export async function rejectDeletion(deletionId: string) {
  // Rejecting means: keep the track everywhere. We re-add the key to the
  // snapshot of the member it disappeared from, so next run doesn't
  // re-flag it — practically, that member's own copy stays deleted
  // locally, but we stop treating the gap as news.
  const del = await db.pendingDeletion.findUniqueOrThrow({ where: { id: deletionId } });
  await db.pendingDeletion.update({ where: { id: deletionId }, data: { status: "rejected", resolvedAt: new Date() } });
}
